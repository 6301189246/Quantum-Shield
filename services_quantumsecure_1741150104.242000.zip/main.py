import os
from flask import Flask, request, jsonify
from google.cloud import storage

app = Flask(__name__)

# Set your GCS bucket name
BUCKET_NAME = "your-bucket-name"

# Initialize Google Cloud Storage client
storage_client = storage.Client()
bucket = storage_client.bucket(BUCKET_NAME)

@app.route("/", methods=["GET"])
def home():
    return "Welcome to the File Upload API!"

@app.route("/upload", methods=["POST"])
def upload_file():
    if "file" not in request.files:
        return jsonify({"error": "No file part in the request"}), 400
    
    file = request.files["file"]
    if file.filename == "":
        return jsonify({"error": "No selected file"}), 400
    
    # Upload to GCS
    blob = bucket.blob(file.filename)
    blob.upload_from_file(file)
    
    return jsonify({"message": "File uploaded successfully!", "file_url": f"https://storage.googleapis.com/{BUCKET_NAME}/{file.filename}"}), 200

# ✅ Cloud Run expects this function as an entry point
def hello_http(request):
    return app(request)
